function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 ABC College of Engineering</p>
    </footer>
  );
}

export default Footer;