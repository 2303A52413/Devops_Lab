function StudentCard({ student }) {
  const eligible = student.attendance >= 75;

  return (
    <div className="student-card">
      <h3>{student.name}</h3>

      <p>
        <strong>Roll Number:</strong> {student.rollNumber}
      </p>

      <p>
        <strong>Branch:</strong> {student.branch}
      </p>

      <p>
        <strong>Attendance:</strong> {student.attendance}%
      </p>

      <p>
        <strong>Status:</strong>{" "}
        {eligible ? "Eligible" : "Not Eligible"}
      </p>

      <button>View Profile</button>
    </div>
  );
}

export default StudentCard;