function Header() {
  return (
    <header className="header">
      <h1>Student Management Dashboard</h1>
      <p>ABC College of Engineering</p>
    </header>
  );
}

export default Header;