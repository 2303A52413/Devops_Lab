function ExamDetails() {
  return (
    <div className="card">
      <h2>Examination Details</h2>

      <p><strong>Exam:</strong> End Semester Examination</p>
      <p><strong>Date:</strong> 15 December 2026</p>
      <p><strong>Semester:</strong> VII Semester</p>
      <p><strong>Venue:</strong> Main Examination Hall</p>
    </div>
  );
}

export default ExamDetails;