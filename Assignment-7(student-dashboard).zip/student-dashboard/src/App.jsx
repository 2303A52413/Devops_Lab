import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import Footer from "./components/Footer";
import StudentCard from "./components/StudentCard";

import "./App.css";

function App() {
  const student = {
    name: "Varshitha",
    rollNumber: "23CS001",
    branch: "CSE - AIML",
    year: "4th Year",
  };

  const subjects = [
    "DevOps and Full Stack",
    "Machine Learning",
    "Deep Learning",
    "Cloud Computing",
    "Software Engineering",
  ];

  const attendance = 82;

  const students = [
    {
      name: "Varshitha",
      rollNumber: "23CS001",
      branch: "CSE - AIML",
      attendance: 82,
    },
    {
      name: "Rahul",
      rollNumber: "23CS002",
      branch: "CSE",
      attendance: 68,
    },
    {
      name: "Sneha",
      rollNumber: "23CS003",
      branch: "CSE - DS",
      attendance: 91,
    },
  ];

  return (
    <>
      <Header />

      <main className="dashboard">

        <StudentProfile
          name={student.name}
          rollNumber={student.rollNumber}
          branch={student.branch}
          year={student.year}
        />

        <SubjectList subjects={subjects} />

        <Attendance percentage={attendance} />

        <ExamDetails />

        <section className="students-section">
          <h2>Students</h2>

          <div className="student-container">
            {students.map((student, index) => (
              <StudentCard
                key={index}
                student={student}
              />
            ))}
          </div>
        </section>

      </main>

      <Footer />
    </>
  );
}

export default App;